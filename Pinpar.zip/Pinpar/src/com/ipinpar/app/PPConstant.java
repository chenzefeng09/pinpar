package com.ipinpar.app;


public class PPConstant {
	public static final String BASE_PATH = ";";
	public static final String DISK_CACHE_PATH =";";

}
