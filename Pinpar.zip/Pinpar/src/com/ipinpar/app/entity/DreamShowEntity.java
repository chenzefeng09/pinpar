package com.ipinpar.app.entity;

import android.R.integer;

public class DreamShowEntity {
	
	public int uid;
	public long createtime;
	public String username;
	public String title;
	public String detail;
	public int commentcount;
	public int status;
	public String imgsrc;
	public String author_img;
	public int dreamid;
	public int agreecount;

}
