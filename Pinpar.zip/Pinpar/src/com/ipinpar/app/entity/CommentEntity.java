package com.ipinpar.app.entity;

import java.util.ArrayList;

public class CommentEntity {
	private int agreecount;
	private String author;
	private int authorid;
	private String authorimg;
	private String comment;
	private int commentid;
	private long commenttime;
	private int commenttype;
	private int flag;
	private int from_id;
	private String from_idtype;
	private ArrayList<ReplyEntity> replys;
	public int getAgreecount() {
		return agreecount;
	}
	public void setAgreecount(int agreecount) {
		this.agreecount = agreecount;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getAuthorid() {
		return authorid;
	}
	public void setAuthorid(int authorid) {
		this.authorid = authorid;
	}
	public String getAuthorimg() {
		return authorimg;
	}
	public void setAuthorimg(String authorimg) {
		this.authorimg = authorimg;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getCommentid() {
		return commentid;
	}
	public void setCommentid(int commentid) {
		this.commentid = commentid;
	}
	public long getCommenttime() {
		return commenttime;
	}
	public void setCommenttime(long commenttime) {
		this.commenttime = commenttime;
	}
	public int getCommenttype() {
		return commenttype;
	}
	public void setCommenttype(int commenttype) {
		this.commenttype = commenttype;
	}
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public int getFrom_id() {
		return from_id;
	}
	public void setFrom_id(int from_id) {
		this.from_id = from_id;
	}
	public String getFrom_idtype() {
		return from_idtype;
	}
	public void setFrom_idtype(String from_idtype) {
		this.from_idtype = from_idtype;
	}
	public ArrayList<ReplyEntity> getReplys() {
		return replys;
	}
	public void setReplys(ArrayList<ReplyEntity> replys) {
		this.replys = replys;
	}

}
