package com.ipinpar.app.entity;


public class PartyRoleIdEntity{
	private int roleid;

	public int getRoleid() {
		return roleid;
	}

	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}

	@Override
	public String toString() {
		return "PartyRoleIdEntity [roleid=" + roleid + "]";
	}

}
