package com.ipinpar.app.entity;

public class CurrDreamShowEntity {
	public int uid;
	public int period;
	public int doid;
	public long createtime;
	public String username;
	public String title;
	public String detail;
	public int commentcount;
	public int status;
	public String imgsrc;
	public String mainimg;
	public String author_img;
	public int dreamid;
	public int agreecount;
}
