package com.ipinpar.app.entity;


public class HobbyEntity {

	private int hid;
	private String hname;
	public int getHid() {
		return hid;
	}
	public void setHid(int hid) {
		this.hid = hid;
	}
	public String getHname() {
		return hname;
	}
	public void setHname(String hname) {
		this.hname = hname;
	}
	
}
