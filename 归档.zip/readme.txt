Git is a distributed version control system.
Git is free software  distributed under the GPL.
Creating a new branch is quick.
Creating a new branch is quick AND simple.
add merge